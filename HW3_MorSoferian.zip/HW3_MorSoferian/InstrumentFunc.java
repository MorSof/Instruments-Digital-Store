
public interface InstrumentFunc<T> extends Comparable<T>, Cloneable {
	
}
